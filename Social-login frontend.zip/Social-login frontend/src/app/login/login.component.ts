import { Component, OnInit } from '@angular/core';
import { GoogleLoginProvider,FacebookLoginProvider,AuthService} from 'angular-6-social-login';
import { SocialLoginModule,AuthServiceConfig} from 'angular-6-social-login';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
