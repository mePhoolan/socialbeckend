const fs = require("fs")
const express=require('express')
const router=express.Router();
const path=require('path')




class UserRouter{


    constructor() {
        this.info = {};
        this.router = router;
        
    }

    loadUserClasses() {
        fs.readdirSync(path.resolve("./controllers/")).forEach(file => {
              let name = file.substr(0, file.indexOf("."));
              console.log("thisis my cofdknfd",name);
              this.info[name] = require(path.resolve(`./controllers/${name}`));
            //   this.router = router;
              console.log("hello all files",this.info[name])
        });
    }

    userRoutes() {
        return [
              {
                url: "/socialinfo",
                method: this.info.socialUserController.socialInfo,
                type: "get"
            }]

        }

init() {
    this.loadUserClasses();
   this.userRoutes();
    return this.router;
}
}
module.exports=UserRouter