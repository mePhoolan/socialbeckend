require('./mongoose')
let express=require('express');
let app=express()
let UserRouter=require('./Routes/routes.js')



                                                                                                                                                                                                                            app.use(UserRouter)
// UserRouter = new UserRouter(                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ).init();
 app.use('/api', new UserRouter().init())
// app.use('/api',UserRouter)


app.listen(5000)
console.log("this is runnig on 3000")

