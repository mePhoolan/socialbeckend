class MyController{

    MyInfo(req,res){
     res.json({message:"this is my message"})
    }
    }
    module.exports=MyController;
    