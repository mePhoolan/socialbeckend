class newController {

    static getInfo(req, res) {

        res.json({message: 'woking'});
    }


}

module.exports = newController;