class socialUserController {

   
        static socialInfo(req,res){
        res.json({message:"this is my message"})
        }
}
module.exports=socialUserController;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
